package DAL;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.User;

/**
 *
 * @author AnhVo-PC
 */
public class UserDAO extends BaseDAO<User> {

    @Override
    public ArrayList<User> getAll() {
        ArrayList<User> user = new ArrayList<>();
        try {
            String sql = "SELECT * FROM [DummyTBL]";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                User s = new User();
                s.setId(rs.getInt(1));
                s.setName(rs.getString(2));
                user.add(s);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return user;
    }

    public int count() {
        String sql = "SELECT COUNT(*) as totalrow FROM [DummyTBL]";
        PreparedStatement statement;
        try {
            statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return rs.getInt("totalrow");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    public ArrayList<User> paging(int pageindex, int pagesize) {
        String sql = "SELECT ID, Name FROM\n"
                + "(SELECT ROW_NUMBER() OVER \n"
                + "(ORDER BY id ASC) as rownum, u.ID, u.Name\n"
                + "FROM [DummyTBL] u) as tblUser\n"
                + "WHERE rownum >= ((?-1) * ?) + 1 AND rownum <= ? * ?";
        ArrayList<User> user1 = new ArrayList<>();
        PreparedStatement statement;
        try {
            statement = connection.prepareStatement(sql);
            statement.setInt(1, pageindex);
            statement.setInt(2, pagesize);
            statement.setInt(3, pagesize);
            statement.setInt(4, pageindex);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                User s = new User();
                s.setId(rs.getInt("ID"));
                s.setName(rs.getString("Name"));
                user1.add(s);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return user1;
    }
}
