package controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Student;

/**
 *
 * @author AnhVo-PC
 */
public class StudentServlet extends HttpServlet {
    private Random rd = new Random();
    public String name() {
        StringBuilder sb = new StringBuilder();
        String s = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        
        for (int i=0; i<rd.nextInt(3)+4; i++) {
            int temp = rd.nextInt(s.length());
            sb.append(s.charAt(temp));
        }
        return sb.toString();
    }
    public String dob() {
        StringBuilder sb = new StringBuilder();
        
        int MM = rd.nextInt(12)+1;
        int dd;
        if(MM==2){
            dd = rd.nextInt(28)+1;
        }else{
            dd = rd.nextInt(31)+1;
        }
        int n = 2003 - 1974 + 1;
        int i = rd.nextInt(31) % n;
        int yyyy =  1974 + i;
        sb.append(dd).append("-").append(MM).append("-").append(yyyy);
   
        return sb.toString();
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String param = request.getParameter("id");

        ArrayList<Student> students = new ArrayList<Student>();

        SimpleDateFormat date = new SimpleDateFormat("dd-MM-yyyy");
        try {
            for (int id = 1; id <= Integer.parseInt(param); id++) {
                students.add(new Student(id, name(), rd.nextBoolean(), date.parse(dob())));
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (param == null || param.equals("")) {
            response.sendRedirect("index.html");
        } else {
            request.setAttribute("param", param);
            request.setAttribute("StudentList", students);
            request.getRequestDispatcher("student.jsp").forward(request, response);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
