import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author AnhVo-PC
 */
public class AddCookies extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        String remember = request.getParameter("remember");
        if (remember != null) {
            Cookie c_user = new Cookie("username", username);
            Cookie c_pass = new Cookie("password", password);
            c_user.setMaxAge(3600 * 24 * 30);
            c_pass.setMaxAge(3600 * 24 * 30);
            response.addCookie(c_pass);
            response.addCookie(c_user);
            response.getWriter().println("login successful!");
        }else { //login fail
            response.getWriter().println("username/password is invalid");
        }
        
//        Cookie cookie = new Cookie("name", "billy");
//        cookie.setMaxAge(3600 * 24 * 7 * 365);
//        response.addCookie(cookie);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userName = request.getParameter("username");
        String password = request.getParameter("password");
        if (userName != null && userName.trim().length() > 0 && password != null && password.trim().length() > 0) {
            System.out.println(userName + ":" + password);
            if (userName != null && userName.length() != 0 && userName.equals("roy") && password != null
                    && password.length() != 0 && password.equals("roy")) {
                if (request.getParameter("remember") != null) {
                    String remember = request.getParameter("remember");
                    System.out.println("remember : " + remember);
                    Cookie cUserName = new Cookie("cookuser", userName.trim());
                    Cookie cPassword = new Cookie("cookpass", userName.trim());
                    Cookie cRemember = new Cookie("cookrem", remember.trim());
                    cUserName.setMaxAge(60 * 60 * 24 * 15);// 15 days
                    cPassword.setMaxAge(60 * 60 * 24 * 15);
                    cRemember.setMaxAge(60 * 60 * 24 * 15);
                    response.addCookie(cUserName);
                    response.addCookie(cPassword);
                    response.addCookie(cRemember);
                }
                HttpSession httpSession = request.getSession();
                httpSession.setAttribute("sessuser", userName.trim());
                RequestDispatcher requestDispatcher = request.getRequestDispatcher("/home.jsp");
                requestDispatcher.forward(request, response);
            } else {
                System.out.println("Authentication failure.");
                request.setAttribute("msg", "Authentication failure.");
                RequestDispatcher requestDispatcher = request.getRequestDispatcher("/login.jsp");
                requestDispatcher.forward(request, response);
            }
        } else {
            System.out.println("Username and Password are required fields.");
            request.setAttribute("msg", "Username and Password are required fields.");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("/login.jsp");
            requestDispatcher.forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
